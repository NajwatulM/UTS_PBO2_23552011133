import java.util.Date;

public class transaksi {
    private int id;
    private int tagihanId;
    private double jumlahBayar;
    private Date tanggal;
    
    public transaksi(int id, int tagihanId, double jumlahBayar, Date tanggal) {
        this.id = id;
        this.tagihanId = tagihanId;
        this.jumlahBayar = jumlahBayar;
        this.tanggal = tanggal;
    }
    
    public int getId() {
        return id;
    }
    
    public int getTagihanId() {
        return tagihanId;
    }
    
    public double getJumlahBayar() {
        return jumlahBayar;
    }
    
    public Date getTanggal() {
        return tanggal;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public void setTagihanId(int tagihanId) {
        this.tagihanId = tagihanId;
    }
    
    public void setJumlahBayar(double jumlahBayar) {
        this.jumlahBayar = jumlahBayar;
    }
    
    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }
}
