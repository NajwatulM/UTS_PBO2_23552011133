public class civitas extends sivitas {
    private String universitas;
    private String fakultas;
    
    public civitas(String universitas, String fakultas) {
        this.universitas = universitas;
        this.fakultas = fakultas;
    }
    
    public String getUniversitas() {
        return universitas;
    }
    
    public void setUniversitas(String universitas) {
        this.universitas = universitas;
    }
    
    public String getFakultas() {
        return fakultas;
    }
    
    public void setFakultas(String fakultas) {
        this.fakultas = fakultas;
    }
}
