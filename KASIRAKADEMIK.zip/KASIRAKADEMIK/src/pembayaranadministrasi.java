public class pembayaranadministrasi extends pembayaran {
    private final double feePerSemester = 300000; // Contoh biaya per semester
    
    @Override
    public double hitungTagihan(int semester) {
        return semester * feePerSemester;
    }
}
