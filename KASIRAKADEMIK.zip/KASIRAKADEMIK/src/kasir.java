import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class kasir extends JFrame {
    private JTextField namaField, nimField, semesterField, totalField, bayaranField;
    private JButton hitungBtn, bayarBtn;
    private JTable transaksiTable;
    private DefaultTableModel tableModel;
    
    // Objek koneksi database
    private Connection conn;
    
    // Instance untuk perhitungan tagihan (polymorphism)
    private pembayaran pembayaranProcessor = new pembayaranadministrasi();
    
    public kasir() {
        super("Sistem Pembayaran Administrasi Kuliah (JDBC)");
        initDB();
        buildGUI();
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    // Menyusun tampilan GUI
    private void buildGUI() {
        setLayout(new BorderLayout());
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Field input Nama
        formPanel.add(new JLabel("Nama:"));
        namaField = new JTextField(20);
        formPanel.add(namaField);
        
        // Field input NIM
        formPanel.add(new JLabel("NIM:"));
        nimField = new JTextField(20);
        formPanel.add(nimField);
        
        // Field input Semester
        formPanel.add(new JLabel("Semester:"));
        semesterField = new JTextField(20);
        formPanel.add(semesterField);
        
        // Tombol hitung tagihan
        formPanel.add(new JLabel("")); // placeholder
        hitungBtn = new JButton("Hitung Tagihan");
        formPanel.add(hitungBtn);
        
        // Menampilkan total tagihan
        formPanel.add(new JLabel("Total Tagihan:"));
        totalField = new JTextField(20);
        totalField.setEditable(false);
        formPanel.add(totalField);
        
        // Field input jumlah bayar
        formPanel.add(new JLabel("Jumlah Bayar:"));
        bayaranField = new JTextField(20);
        formPanel.add(bayaranField);
        
        // Tombol proses pembayaran
        formPanel.add(new JLabel("")); // placeholder
        bayarBtn = new JButton("Bayar");
        formPanel.add(bayarBtn);
        
        add(formPanel, BorderLayout.NORTH);
        
        // Tabel untuk menampilkan data transaksi
        tableModel = new DefaultTableModel(new Object[] {
            "Transaksi ID", "Tagihan ID", "NIM", "Nama", "Semester", "Total Tagihan", "Jumlah Bayar", "Tanggal"
        }, 0);
        transaksiTable = new JTable(tableModel);
        add(new JScrollPane(transaksiTable), BorderLayout.CENTER);
        
        // Event listener untuk tombol hitung tagihan
        hitungBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                hitungTagihanAction();
            }
        });
        
        // Event listener untuk tombol bayar
        bayarBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                prosesPembayaran();
            }
        });
    }
    
    // Inisialisasi koneksi ke database
    private void initDB() {
    try {
        // Menggunakan kelas DatabaseConnection yang sudah terpisah
        conn = koneksi.getConnection();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Koneksi database gagal: " + ex.getMessage());
        System.exit(1);
    }
}

    
    // Menghitung tagihan menggunakan polymorphism
    // Menghitung tagihan menggunakan polymorphism dan memastikan mahasiswa ada di database
    private void hitungTagihanAction() {
        try {
            // Ambil NIM dari field, pastikan tidak kosong.
            String nim = nimField.getText().trim();
            if(nim.isEmpty()){
                JOptionPane.showMessageDialog(this, "NIM harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Periksa apakah mahasiswa dengan NIM tersebut sudah ada di database
            if (!isMahasiswaExists(nim)) {
                JOptionPane.showMessageDialog(this, "Mahasiswa dengan NIM " + nim + " tidak ditemukan di database!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Jika mahasiswa ada, lanjutkan perhitungan tagihan
            int semester = Integer.parseInt(semesterField.getText().trim());
            double total = pembayaranProcessor.hitungTagihan(semester);
            totalField.setText(String.valueOf(total));
        } catch(NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Semester harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saat memeriksa data mahasiswa: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Memproses pembayaran dan menyimpan data ke database
    private void prosesPembayaran() {
        String nama = namaField.getText().trim();
        String nim = nimField.getText().trim();
        String semesterStr = semesterField.getText().trim();
        String totalStr = totalField.getText().trim();
        String bayarStr = bayaranField.getText().trim();
        
        if(nama.isEmpty() || nim.isEmpty() || semesterStr.isEmpty() || totalStr.isEmpty() || bayarStr.isEmpty()){
            JOptionPane.showMessageDialog(this, "Semua field harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int semester;
        double totalTagihan, jumlahBayar;
        try {
            semester = Integer.parseInt(semesterStr);
            totalTagihan = Double.parseDouble(totalStr);
            jumlahBayar = Double.parseDouble(bayarStr);
        } catch(NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Input semester, total tagihan, dan jumlah bayar harus angka!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            // Jika mahasiswa belum ada, masukkan ke tabel mahasiswa
            if (!isMahasiswaExists(nim)) {
                insertMahasiswa(nim, nama);
            }
            
            int tagihanId = insertTagihan(nim, semester, totalTagihan);
            if(tagihanId == -1) {
                JOptionPane.showMessageDialog(this, "Gagal membuat tagihan!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int transaksiId = insertTransaksi(tagihanId, jumlahBayar);
            if(transaksiId == -1) {
                JOptionPane.showMessageDialog(this, "Gagal membuat transaksi!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String tanggal = new Date().toString();
            tableModel.addRow(new Object[] {
                transaksiId, tagihanId, nim, nama, semester, totalTagihan, jumlahBayar, tanggal
            });
            
            JOptionPane.showMessageDialog(this, "Pembayaran berhasil!");
            clearForm();
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error processing payment: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Mengecek apakah data mahasiswa sudah ada
    private boolean isMahasiswaExists(String nim) throws SQLException {
        String sql = "SELECT nim FROM mahasiswa WHERE nim = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nim);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
    
    // Memasukkan data mahasiswa ke tabel
    private void insertMahasiswa(String nim, String nama) throws SQLException {
        String sql = "INSERT INTO mahasiswa(nama, nim) VALUES(?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nama);
            stmt.setString(2, nim);
            stmt.executeUpdate();
        }
    }
    
    // Memasukkan record tagihan dan mengembalikan generated ID
    private int insertTagihan(String nim, int semester, double total) throws SQLException {
        int tagihanId = -1;
        String sql = "INSERT INTO tagihan(nim, semester, total) VALUES(?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, nim);
            stmt.setInt(2, semester);
            stmt.setDouble(3, total);
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                tagihanId = rs.getInt(1);
            }
        }
        return tagihanId;
    }
    
    // Memasukkan record transaksi dan mengembalikan generated ID
    private int insertTransaksi(int tagihanId, double jumlahBayar) throws SQLException {
        int transaksiId = -1;
        String sql = "INSERT INTO transaksi(tagihan_id, jumlah_bayar, tanggal) VALUES(?, ?, ?)";
        Timestamp timestamp = new Timestamp(new Date().getTime());
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, tagihanId);
            stmt.setDouble(2, jumlahBayar);
            stmt.setTimestamp(3, timestamp);
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                transaksiId = rs.getInt(1);
            }
        }
        return transaksiId;
    }
    
    // Membersihkan field input
    private void clearForm() {
        namaField.setText("");
        nimField.setText("");
        semesterField.setText("");
        totalField.setText("");
        bayaranField.setText("");
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                new kasir();
            }
        });
    }
}
