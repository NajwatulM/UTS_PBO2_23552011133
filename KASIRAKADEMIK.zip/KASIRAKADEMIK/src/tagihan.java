public class tagihan {
    private int id;
    private String nim;
    private int semester;
    private double total;
    
    public tagihan(int id, String nim, int semester, double total) {
        this.id = id;
        this.nim = nim;
        this.semester = semester;
        this.total = total;
    }
    
    public int getId() {
        return id;
    }
    
    public String getNim() {
        return nim;
    }
    
    public int getSemester() {
        return semester;
    }
    
    public double getTotal() {
        return total;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public void setNim(String nim) {
        this.nim = nim;
    }
    
    public void setSemester(int semester) {
        this.semester = semester;
    }
    
    public void setTotal(double total) {
        this.total = total;
    }
}
